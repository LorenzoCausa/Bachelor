const MeasurementTypes = Object.freeze({
    temperature: "temperature [Celsius degree]",
    light: "light [%]"
});

module.exports = MeasurementTypes;
