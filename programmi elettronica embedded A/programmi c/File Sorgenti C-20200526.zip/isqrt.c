#include "isqrt.h"


float isqrt(float x, float y0, float epsilon) {
 
	
}



void compute(float in[DIM1][DIM2][DIM3], float out[DIM1][DIM2][DIM3]) {

	
}
