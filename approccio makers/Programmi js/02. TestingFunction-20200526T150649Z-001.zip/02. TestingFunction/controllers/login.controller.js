exports.isValidUserId =  function(userList, user) {
  return userList.indexOf(user) >= 0;
}
